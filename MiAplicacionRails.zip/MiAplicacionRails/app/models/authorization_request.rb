class AuthorizationRequest < ApplicationRecord
end
