# app/controllers/authorization_requests_controller.rb
class AuthorizationRequestsController < ApplicationController
  skip_before_action :verify_authenticity_token
  def create
    @authorization_request = AuthorizationRequest.new(authorization_request_params)

    ActionCable.server.broadcast("notification_channel", notification: "¡Nueva solicitud de autorización!")

    if @authorization_request.save
      # Aquí podrías enviar una notificación al usuario correspondiente
      render json: { message: 'Solicitud de autorización recibida. El usuario será notificado.' }, status: :created
    else
      render json: @authorization_request.errors, status: :unprocessable_entity
    end
  end

  private

  def authorization_request_params
    params.require(:authorization_request).permit(:app_name, :user_id)
  end
end
