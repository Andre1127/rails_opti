require "test_helper"

class AuthorizationRequestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
